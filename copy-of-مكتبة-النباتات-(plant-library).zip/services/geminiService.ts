
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzePlantImage = async (base64Image: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { inlineData: { data: base64Image, mimeType: 'image/jpeg' } },
            { text: "حلل هذه الصورة لنبات. قدم الاسم الشائع، الاسم العلمي، تصنيف النبتة (فواكه، خضروات، زينة داخلية، زينة خارجية، طبية)، ومعلومات عامة ونصائح للعناية بها. أجب باللغة العربية بتنسيق JSON حصراً." }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            scientificName: { type: Type.STRING },
            category: { type: Type.STRING },
            generalInfo: { type: Type.STRING },
            careInstructions: { type: Type.STRING }
          },
          required: ["name", "scientificName", "category", "generalInfo", "careInstructions"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
};

export const generateStageDescription = async (stage: string, plantName: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `اكتب وصفاً قصيراً ومميزاً لمرحلة الـ (${stage}) لنبات (${plantName}) باللغة العربية. ركز على الملامح الجمالية والتقنية لهذه المرحلة.`
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Description Error:", error);
    return "لا يوجد وصف متاح حالياً.";
  }
};
