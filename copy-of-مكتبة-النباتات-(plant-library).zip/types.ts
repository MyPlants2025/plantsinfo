
export enum PlantCategory {
  FRUIT = 'فواكه',
  VEGETABLE = 'خضروات',
  INDOOR = 'نباتات زينة داخلية',
  OUTDOOR = 'نباتات زينة خارجية',
  MEDICINAL = 'نباتات طبية'
}

export enum GrowthStage {
  SEED = 'بذرة',
  SEEDLING = 'شتلة',
  MATURE = 'نبتة كاملة',
  FLOWER = 'زهرة',
  FRUIT = 'ثمرة'
}

export interface PlantStageEntry {
  id: string;
  stage: GrowthStage;
  imageUrl: string;
  description: string;
  date: string;
}

export interface Plant {
  id: string;
  name: string;
  scientificName: string;
  category: PlantCategory;
  generalInfo: string;
  careInstructions: string;
  stages: PlantStageEntry[];
  createdAt: number;
}

export type AppView = 'dashboard' | 'library' | 'add-plant' | 'plant-detail';
