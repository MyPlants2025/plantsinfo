
import React, { useState, useRef } from 'react';
import { Camera, Loader2, Sparkles, X, Save } from 'lucide-react';
import { analyzePlantImage } from '../services/geminiService';
import { Plant, PlantCategory } from '../types';

interface PlantFormProps {
  onSave: (plant: Partial<Plant>) => void;
  onCancel: () => void;
}

const PlantForm: React.FC<PlantFormProps> = ({ onSave, onCancel }) => {
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    scientificName: '',
    category: PlantCategory.OUTDOOR,
    generalInfo: '',
    careInstructions: ''
  });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setPreview(base64);
      
      // Auto-analyze with AI
      setLoading(true);
      const cleanedBase64 = base64.split(',')[1];
      const analysis = await analyzePlantImage(cleanedBase64);
      
      if (analysis) {
        setFormData({
          name: analysis.name || '',
          scientificName: analysis.scientificName || '',
          category: (analysis.category as PlantCategory) || PlantCategory.OUTDOOR,
          generalInfo: analysis.generalInfo || '',
          careInstructions: analysis.careInstructions || ''
        });
      }
      setLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      stages: preview ? [{
        id: crypto.randomUUID(),
        stage: 'بذرة' as any, // Initial stage
        imageUrl: preview,
        description: 'الصورة الافتتاحية للنبتة',
        date: new Date().toISOString()
      }] : []
    });
  };

  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <div className="bg-white rounded-3xl shadow-xl border border-emerald-50 overflow-hidden">
        <div className="bg-emerald-600 px-6 py-8 text-white relative">
          <h2 className="text-2xl font-bold">إضافة نبتة جديدة</h2>
          <p className="mt-2 text-emerald-100">ارفع صورة لنبتتك ليتعرف عليها الذكاء الاصطناعي ويملأ البيانات لك</p>
          <Sparkles className="absolute left-6 top-8 h-10 w-10 text-emerald-400 opacity-50" />
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {/* Image Upload Area */}
          <div className="relative">
            {preview ? (
              <div className="relative h-64 w-full rounded-2xl overflow-hidden shadow-inner group">
                <img src={preview} className="w-full h-full object-cover" alt="Preview" />
                <button 
                  type="button"
                  onClick={() => { setPreview(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}
                  className="absolute top-2 right-2 bg-white/80 p-2 rounded-full text-red-500 hover:bg-red-50"
                >
                  <X className="h-5 w-5" />
                </button>
                {loading && (
                  <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white">
                    <Loader2 className="h-10 w-10 animate-spin mb-2" />
                    <p>جاري تحليل النبتة...</p>
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-48 border-2 border-dashed border-emerald-200 rounded-2xl flex flex-col items-center justify-center bg-emerald-50 hover:bg-emerald-100 transition-colors"
              >
                <Camera className="h-12 w-12 text-emerald-600 mb-2" />
                <span className="text-emerald-700 font-medium">ارفع صورة للنبتة</span>
                <span className="text-xs text-emerald-500 mt-1">(اختياري للتعرف التلقائي)</span>
              </button>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">اسم النبتة الشائع</label>
              <input 
                required
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none"
                placeholder="مثلاً: نعناع، طماطم..."
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">الاسم العلمي</label>
              <input 
                type="text"
                value={formData.scientificName}
                onChange={(e) => setFormData({...formData, scientificName: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none"
                placeholder="Scientific name"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">تصنيف النبتة</label>
            <select 
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value as PlantCategory})}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none"
            >
              {Object.values(PlantCategory).map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">معلومات عامة</label>
            <textarea 
              rows={3}
              value={formData.generalInfo}
              onChange={(e) => setFormData({...formData, generalInfo: e.target.value})}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none"
              placeholder="اكتب وصفاً مختصراً للنبتة..."
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">تعليمات العناية</label>
            <textarea 
              rows={3}
              value={formData.careInstructions}
              onChange={(e) => setFormData({...formData, careInstructions: e.target.value})}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none"
              placeholder="كيف نعتني بها؟ (الري، الإضاءة، التسميد)..."
            />
          </div>

          <div className="flex space-x-reverse space-x-3 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-xl transition-colors flex items-center justify-center"
            >
              <Save className="h-5 w-5 ml-2" />
              حفظ النبتة
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold py-3 px-6 rounded-xl transition-colors"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PlantForm;
