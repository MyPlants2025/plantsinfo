
import React from 'react';
import { Leaf, Plus, Library, LayoutDashboard } from 'lucide-react';
import { AppView } from '../types';

interface HeaderProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
    { id: 'library', label: 'المكتبة', icon: Library },
    { id: 'add-plant', label: 'إضافة نبتة', icon: Plus },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-emerald-100 shadow-sm no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex items-center cursor-pointer" 
            onClick={() => onNavigate('dashboard')}
          >
            <div className="bg-emerald-600 p-1.5 rounded-lg">
              <Leaf className="h-6 w-6 text-white" />
            </div>
            <span className="mr-2 text-xl font-bold text-emerald-900">مكتبة النباتات</span>
          </div>

          <nav className="hidden md:flex space-x-reverse space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id as AppView)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === item.id
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50/50'
                }`}
              >
                <item.icon className="h-4 w-4 ml-2" />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="md:hidden">
            {/* Mobile simplified nav */}
            <div className="flex items-center space-x-reverse space-x-2">
              <button 
                onClick={() => onNavigate('add-plant')}
                className="p-2 text-emerald-600 bg-emerald-50 rounded-full"
              >
                <Plus className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
