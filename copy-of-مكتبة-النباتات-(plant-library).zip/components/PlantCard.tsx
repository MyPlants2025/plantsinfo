
import React from 'react';
import { ChevronLeft, Info, Sprout } from 'lucide-react';
import { Plant } from '../types';

interface PlantCardProps {
  plant: Plant;
  onClick: (id: string) => void;
}

const PlantCard: React.FC<PlantCardProps> = ({ plant, onClick }) => {
  const latestImage = plant.stages.length > 0 
    ? plant.stages[plant.stages.length - 1].imageUrl 
    : 'https://picsum.photos/seed/plant/400/300';

  return (
    <div 
      className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all group overflow-hidden cursor-pointer"
      onClick={() => onClick(plant.id)}
    >
      <div className="relative h-48 w-full overflow-hidden">
        <img 
          src={latestImage} 
          alt={plant.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-semibold text-emerald-700">
          {plant.category}
        </div>
      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-lg font-bold text-gray-900 group-hover:text-emerald-700 transition-colors">
              {plant.name}
            </h3>
            <p className="text-sm italic text-gray-500">{plant.scientificName}</p>
          </div>
        </div>
        
        <div className="flex items-center mt-4 text-xs text-gray-400">
          <Sprout className="h-3 w-3 ml-1" />
          <span>{plant.stages.length} مراحل مسجلة</span>
          <span className="mx-2">•</span>
          <span>منذ {new Date(plant.createdAt).toLocaleDateString('ar-EG')}</span>
        </div>

        <div className="mt-4 flex items-center justify-end text-emerald-600 font-medium text-sm group-hover:translate-x-[-4px] transition-transform">
          عرض التفاصيل
          <ChevronLeft className="h-4 w-4 mr-1" />
        </div>
      </div>
    </div>
  );
};

export default PlantCard;
