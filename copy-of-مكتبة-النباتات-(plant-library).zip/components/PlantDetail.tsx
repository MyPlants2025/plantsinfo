
import React, { useState, useRef } from 'react';
import { Calendar, Camera, FileText, ChevronRight, Plus, Info, CheckCircle2, Share2, Sparkles, Printer } from 'lucide-react';
import { Plant, GrowthStage, PlantStageEntry } from '../types';
import { generateStageDescription } from '../services/geminiService';

interface PlantDetailProps {
  plant: Plant;
  onAddStage: (plantId: string, stage: PlantStageEntry) => void;
  onBack: () => void;
}

const PlantDetail: React.FC<PlantDetailProps> = ({ plant, onAddStage, onBack }) => {
  const [isAddingStage, setIsAddingStage] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newStage, setNewStage] = useState<{
    stage: GrowthStage;
    imageUrl: string;
    description: string;
  }>({
    stage: GrowthStage.SEEDLING,
    imageUrl: '',
    description: ''
  });

  const handleStageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewStage({ ...newStage, imageUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleAddStageSubmit = async () => {
    if (!newStage.imageUrl) return;
    
    const stageEntry: PlantStageEntry = {
      id: crypto.randomUUID(),
      stage: newStage.stage,
      imageUrl: newStage.imageUrl,
      description: newStage.description,
      date: new Date().toISOString()
    };

    onAddStage(plant.id, stageEntry);
    setIsAddingStage(false);
    setNewStage({ stage: GrowthStage.SEEDLING, imageUrl: '', description: '' });
  };

  const generateAIDescription = async () => {
    setIsGenerating(true);
    const desc = await generateStageDescription(newStage.stage, plant.name);
    setNewStage({ ...newStage, description: desc || '' });
    setIsGenerating(false);
  };

  const printReport = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-4">
      {/* Back button */}
      <button 
        onClick={onBack}
        className="mb-6 flex items-center text-emerald-700 hover:text-emerald-900 font-medium no-print transition-colors"
      >
        <ChevronRight className="h-5 w-5 ml-1" />
        العودة للمكتبة
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Plant Summary Info */}
        <div className="lg:col-span-1 space-y-6 no-print">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-50 sticky top-24">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{plant.name}</h1>
            <p className="text-emerald-600 font-medium mb-6">{plant.scientificName}</p>
            
            <div className="space-y-4">
              <div className="flex items-center text-sm text-gray-600">
                <Info className="h-5 w-5 ml-3 text-emerald-500" />
                <div>
                  <p className="font-semibold text-gray-900">التصنيف</p>
                  <p>{plant.category}</p>
                </div>
              </div>
              <div className="flex items-start text-sm text-gray-600">
                <Calendar className="h-5 w-5 ml-3 text-emerald-500 mt-0.5" />
                <div>
                  <p className="font-semibold text-gray-900">تاريخ البدء</p>
                  <p>{new Date(plant.createdAt).toLocaleDateString('ar-EG')}</p>
                </div>
              </div>
              <div className="flex items-start text-sm text-gray-600">
                <CheckCircle2 className="h-5 w-5 ml-3 text-emerald-500 mt-0.5" />
                <div>
                  <p className="font-semibold text-gray-900">مراحل النمو</p>
                  <p>{plant.stages.length} مراحل مسجلة</p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col gap-3">
              <button 
                onClick={() => setIsAddingStage(true)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center"
              >
                <Plus className="h-5 w-5 ml-2" />
                إضافة مرحلة جديدة
              </button>
              <button 
                onClick={printReport}
                className="w-full bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-50 font-bold py-3 rounded-xl transition-colors flex items-center justify-center"
              >
                <Printer className="h-5 w-5 ml-2" />
                طباعة تقرير PDF
              </button>
            </div>
          </div>
        </div>

        {/* Growth Timeline & Details */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-emerald-50">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <div className="bg-emerald-100 p-2 rounded-lg ml-3">
                <FileText className="h-6 w-6 text-emerald-600" />
              </div>
              معلومات العناية العامة
            </h2>
            <div className="prose prose-emerald max-w-none">
              <h4 className="text-lg font-bold text-emerald-800 mb-2">عن النبتة:</h4>
              <p className="text-gray-700 mb-6 leading-relaxed">{plant.generalInfo}</p>
              
              <h4 className="text-lg font-bold text-emerald-800 mb-2">تعليمات العناية:</h4>
              <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{plant.careInstructions}</p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <div className="bg-emerald-100 p-2 rounded-lg ml-3">
                <Camera className="h-6 w-6 text-emerald-600" />
              </div>
              سجل النمو الموثق
            </h2>
            
            <div className="space-y-8 relative before:absolute before:inset-0 before:mr-5 before:w-0.5 before:bg-emerald-100 before:pointer-events-none">
              {plant.stages.map((entry, idx) => (
                <div key={entry.id} className="relative pr-12 group">
                  <div className="absolute right-0 top-0 h-10 w-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold z-10 border-4 border-white shadow-sm transition-transform group-hover:scale-110">
                    {idx + 1}
                  </div>
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-50 hover:shadow-md transition-shadow">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="w-full md:w-48 h-48 rounded-2xl overflow-hidden flex-shrink-0 shadow-inner">
                        <img src={entry.imageUrl} className="w-full h-full object-cover" alt={entry.stage} />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <span className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                              {entry.stage}
                            </span>
                            <p className="text-sm text-gray-400 mt-2">
                              {new Date(entry.date).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </p>
                          </div>
                        </div>
                        <p className="text-gray-700 leading-relaxed mt-4">
                          {entry.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Add Stage Modal */}
      {isAddingStage && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm no-print">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="bg-emerald-600 p-6 text-white flex justify-between items-center">
              <h3 className="text-xl font-bold">توثيق مرحلة جديدة</h3>
              <button onClick={() => setIsAddingStage(false)}>
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              <div 
                className="h-48 border-2 border-dashed border-emerald-200 rounded-2xl flex flex-col items-center justify-center bg-emerald-50 cursor-pointer overflow-hidden relative"
                onClick={() => fileInputRef.current?.click()}
              >
                {newStage.imageUrl ? (
                  <img src={newStage.imageUrl} className="w-full h-full object-cover" />
                ) : (
                  <>
                    <Camera className="h-10 w-10 text-emerald-600 mb-2" />
                    <span className="text-emerald-700 font-medium">التقط صورة أو ارفع ملف</span>
                  </>
                )}
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleStageFileChange} />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">اختر المرحلة</label>
                <div className="grid grid-cols-3 gap-2">
                  {Object.values(GrowthStage).map((s) => (
                    <button
                      key={s}
                      onClick={() => setNewStage({...newStage, stage: s})}
                      className={`py-2 px-3 rounded-lg text-xs font-medium transition-colors ${
                        newStage.stage === s ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-emerald-100'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-semibold text-gray-700">وصف الصورة</label>
                  <button 
                    onClick={generateAIDescription}
                    disabled={isGenerating}
                    className="text-xs text-emerald-600 hover:text-emerald-800 flex items-center font-bold"
                  >
                    {isGenerating ? <Loader2 className="h-3 w-3 animate-spin ml-1" /> : <Sparkles className="h-3 w-3 ml-1" />}
                    وصف ذكي (AI)
                  </button>
                </div>
                <textarea 
                  rows={4}
                  value={newStage.description}
                  onChange={(e) => setNewStage({...newStage, description: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                  placeholder="اكتب تفاصيل عن حالة النبتة في هذه المرحلة..."
                />
              </div>

              <div className="flex space-x-reverse space-x-3">
                <button
                  onClick={handleAddStageSubmit}
                  disabled={!newStage.imageUrl}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-300 text-white font-bold py-3 rounded-xl transition-colors"
                >
                  حفظ المرحلة
                </button>
                <button
                  onClick={() => setIsAddingStage(false)}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold py-3 rounded-xl transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const X = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>;
const Loader2 = ({ className }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;

export default PlantDetail;
